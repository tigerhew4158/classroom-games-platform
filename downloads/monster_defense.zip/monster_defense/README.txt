P005 monster_defense
Open index.html to play offline.

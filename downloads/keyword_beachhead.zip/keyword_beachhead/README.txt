P007 keyword_beachhead
Open index.html to play offline.

P006 find_difference
Open index.html to play offline.

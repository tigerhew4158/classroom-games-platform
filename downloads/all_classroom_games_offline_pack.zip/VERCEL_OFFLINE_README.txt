All classroom games offline pack. Open index.html after extracting.

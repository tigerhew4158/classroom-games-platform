H008 kingdom_resource_battle
Open index.html to play offline.

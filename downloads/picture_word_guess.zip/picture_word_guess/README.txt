H004 picture_word_guess
Open index.html to play offline.

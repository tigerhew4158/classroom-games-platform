P010 team_relay_quiz
Open index.html to play offline.

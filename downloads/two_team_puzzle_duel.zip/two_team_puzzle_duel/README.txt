H006 two_team_puzzle_duel
Open index.html to play offline.

P009 image_label_match
Open index.html to play offline.

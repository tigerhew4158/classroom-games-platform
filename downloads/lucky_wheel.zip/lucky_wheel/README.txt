S005 lucky_wheel
Open index.html to play offline.

S004 treasure_box
Open index.html to play offline.

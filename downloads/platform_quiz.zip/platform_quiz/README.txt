H001 platform_quiz
Open index.html to play offline.

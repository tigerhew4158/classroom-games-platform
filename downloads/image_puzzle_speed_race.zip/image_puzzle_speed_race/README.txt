P002 image_puzzle_speed_race
Open index.html to play offline.

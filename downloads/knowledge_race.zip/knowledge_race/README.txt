P004 knowledge_race
Open index.html to play offline.

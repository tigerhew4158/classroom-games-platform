S007 whack_mole
Open index.html to play offline.

P003 bomb_quiz
Open index.html to play offline.
